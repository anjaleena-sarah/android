package com.example.tabgriddemo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class TabFragment1 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_content_layout, container, false);
        GridView gridView = view.findViewById(R.id.grid_view);
        // Setup your adapter and data for the grid view
        gridView.setAdapter(new GridAdapter(getActivity(), getData()));
        return view;
    }

    private List<String> getData() {
        // Dummy data for the grid view
        List<String> data = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            data.add("Item " + (i + 1));
        }
        return data;
    }
}
