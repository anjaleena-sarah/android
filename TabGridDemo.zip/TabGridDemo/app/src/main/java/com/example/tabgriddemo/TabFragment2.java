package com.example.tabgriddemo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class TabFragment2 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tab_content_layout, container, false);

        // Find the GridView in the inflated layout
        GridView gridView = view.findViewById(R.id.grid_view);

        // Set up adapter and data for the GridView
        gridView.setAdapter(new GridAdapter(getActivity(), getData()));

        return view;
    }

    // Method to generate dummy data for the GridView
    private List<String> getData() {
        List<String> data = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            data.add("Item " + (i + 1));
        }
        return data;
    }
}
