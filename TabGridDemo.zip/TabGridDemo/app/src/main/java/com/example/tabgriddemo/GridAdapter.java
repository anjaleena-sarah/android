package com.example.tabgriddemo;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

import java.util.List;

public class GridAdapter extends BaseAdapter {

    private final Context context;
    private final List<String> data;

    public GridAdapter(Context context, List<String> data) {
        this.context = context;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView textView;
        if (convertView == null) {
            // If convertView is null, inflate a new TextView
            textView = new TextView(context);
            textView.setLayoutParams(new GridView.LayoutParams(GridView.AUTO_FIT, 100)); // Set item size
            textView.setPadding(8, 8, 8, 8); // Set padding
        } else {
            // If convertView is not null, reuse it
            textView = (TextView) convertView;
        }

        // Set text from data list at current position
        textView.setText(data.get(position));

        return textView;
    }
}
