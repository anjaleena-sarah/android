package com.example.contactlistview;

import android.os.Bundle;
import android.view.View;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayList<String> contacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        contacts = new ArrayList<>();

        // Add some sample contacts
        contacts.add("Anjaleena Sarah - 9878786765");
        contacts.add("Alfia A H - 9453678745");
        contacts.add("Albin Joseph - 9899884534");
        contacts.add("Anjali Venu - 8988773964");
        contacts.add("Bhagya Bijoy - 9098785321");
        contacts.add("Kavya Nair - 7798634589");
        contacts.add("Elna Mary - 8932451422");
        contacts.add("Senita Merin- 9021265428");
        contacts.add("Glereena Mary - 8902547816");
        contacts.add("Jewel K S - 7897755643");
        contacts.add("Leya Benny - 9090878766");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, contacts);
        listView.setAdapter(adapter);

        // Correct the window insets application
        View rootView = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}